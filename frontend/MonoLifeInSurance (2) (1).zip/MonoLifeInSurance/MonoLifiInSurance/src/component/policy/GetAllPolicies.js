import React from 'react'

function GetAllPolicies() {
const [pageNumber, setPageNumber] = useState(0);
const [pageSize, setPageSize] = useState(2);
const [totalPages, setTotalPages] = useState();
const [totalElements, setTotalElements] = useState('');
const [data, setData] = useState([])

 const GetPolicies=async()=>
 {
    let response = await AllPolicies(pageNumber,pageSize);
    console.log("policies are ------------>",response);
    setData(response.data.content);
 }




  return (
    <div>get all policies</div>
  )
}

export default GetAllPolicies