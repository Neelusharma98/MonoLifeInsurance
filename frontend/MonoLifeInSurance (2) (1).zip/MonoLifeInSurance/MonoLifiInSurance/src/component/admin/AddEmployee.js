import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { useState } from 'react';
import { eightCharAlphanumericPasswordRegex, emailRegex, houseNoRegex, mobileRegex, nameRegex, pinRegex, salaryRegex } from '../../validation/Validation';
import { errorApartment, errorCity, errorEmail, errorFirstname, errorHouseNo, errorLastname, errorMobile, errorPassword, errorPin, errorSalary, errorState } from '../../validation/ErrorMessage';

function AddEmployee(data) {

    data = data.data;

    console.log(data);

    const handleClose = () => data.setShow(false);
    const handleShow = () => data.setShow(true);
    const [msg,setMsg]=useState('');
    const handleSubmit = () => {

        data.addEmployeeHandler();
        data.setShow(false);

    }




    return (
        <>


            <Modal
                show={data.show}
                onHide={handleClose}
                backdrop="static"
                keyboard={false}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Add Employee</Modal.Title>
                   
                </Modal.Header>
                <div className="text-danger text-center fw-bold">{msg}</div>
                <Modal.Body>

                    <form className="p-2">
                        <div className='container'>
                            <div className='row'>
                                <div className='col-6'>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingInput"
                                        placeholder='firstName'
                                        value={data.firstName}

                                        onChange={
                                            (e)=>{
                                                data.setFirstName(e.target.value)
                                                if(!nameRegex.test(e.target.value))
                                                {setMsg(errorFirstname)
                                                }
                                               else{setMsg('')
                                                }
                                            }
                                            
                                        }
                                        
                                        />
                                        <label for="floatingInput">First Name</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingInput"
                                         value={data.mobileNumber}
                                         placeholder='mobile'

                                         onChange={
                                             (e)=>{
                                                 data.setMobileNumber(e.target.value)
                                                 if(!mobileRegex.test(e.target.value))
                                                {setMsg(errorMobile)
                                                }
                                               else{setMsg('')
                                                }
                                             }
                                             
                                         }
                                        
                                        />
                                        <label for="floatingInput">Mobile Number</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control rounded-pill" id="floatingPassword" 
                                        placeholder='salary'
                                        value={data.salary}

                                         onChange={
                                             (e)=>{
                                                 data.setSalary(e.target.value)
                                                 if(!salaryRegex.test(e.target.value))
                                                {setMsg(errorSalary)
                                                }
                                               else{setMsg('')
                                                }
                                             }
                                             
                                         }
                                
                                        
                                        />
                                        <label for="floatingPassword">Salary</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingInput"
                                        value={data.userName}
                                        placeholder='username'

                                        onChange={
                                            (e)=>{
                                                data.setUsername(e.target.value)
                                            }
                                            
                                        }
                               
                                        
                                        />
                                        <label for="floatingInput">Username</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingPassword"
                                        placeholder='password'
                                        value={data.password}

                                         onChange={
                                             (e)=>{
                                                 data.setPassword(e.target.value)
                                                 if(!eightCharAlphanumericPasswordRegex.test(e.target.value))
                                                 {setMsg(errorPassword)
                                                 }
                                                else{setMsg('')
                                                 }
                                             }
                                             
                                         }
                                
                                        />
                                        <label for="floatingPassword">Password</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingPassword" 
                                        placeholder='state'
                                        value={data.state}

                                         onChange={
                                             (e)=>{
                                                 data.setState(e.target.value)
                                                 if(!nameRegex.test(e.target.value))
                                                 {setMsg(errorState)
                                                 }
                                                else{setMsg('')
                                                 }
                                             }
                                             
                                         }
                                
                                        />
                                        <label for="floatingPassword">State</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input type="number" class="form-control rounded-pill" id="floatingPassword"
                                        placeholder='pinCode'
                                        value={data.pincode}

                                         onChange={
                                             (e)=>{
                                                 data.setPincode(e.target.value)
                                                 if(!pinRegex.test(e.target.value))
                                                {setMsg(errorPin)
                                                }
                                               else{setMsg('')
                                                }
                                             }
                                             
                                         }
                                
                                        
                                        />
                                        <label for="floatingPassword">Pincode</label>
                                    </div>

                                </div>
                                <div className='col-6'>

                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingPassword"
                                        value={data.lastName}
                                        placeholder='LastName'
                                        onChange={
                                            (e)=>{
                                                data.setLastName(e.target.value)
                                                if(!nameRegex.test(e.target.value))
                                                {setMsg(errorLastname)
                                                }
                                               else{setMsg('')
                                                }
                                            }
                                            
                                        }
                               
                                        
                                        />
                                        <label for="floatingPassword">Last Name</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="email" class="form-control rounded-pill" id="floatingInput" placeholder="name@example.com" 
                                        
                                        value={data.email}

                                         onChange={
                                             (e)=>{
                                                 data.setEmail(e.target.value)
                                                 if(!emailRegex.test(e.target.value))
                                                {setMsg(errorEmail)
                                                }
                                               else{setMsg('')
                                                }
                                             }
                                             
                                         }
                                
                                        
                                        />
                                        <label for="floatingInput">Email address</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" placeholder='YYYY-MM-DD'
                                        value={data.dateOfBirth}

                                         onChange={
                                             (e)=>{
                                                const selectedDate = e.target.value;
                                                const formattedDate = new Date(selectedDate).toISOString().split('T')[0];
                                                console.log(formattedDate);
                                                data.setDateOfBirth(formattedDate)
                                             }
                                             
                                         }
                                
                                        
                                        />
                                        <label for="floatingPassword">Date Of Birth</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input  type="date" id="DOB" name="DOB" min="1979-01" max="2020-01"
                                        placeholder='houseNo'
                                        value={data.houseNo}

                                         onChange={
                                             (e)=>{
                                                
                                                 data.setHouseNo(e.target.value)
                                                 if(!houseNoRegex.test(e.target.value))
                                                 {setMsg(errorHouseNo)
                                                 }
                                                else{setMsg('')
                                                 }
                                             }
                                             
                                         }
                                
                                        />
                                        <label for="floatingPassword">House Number</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingPassword"
                                        placeholder='apartment'
                                        value={data.apartment}

                                         onChange={
                                             (e)=>{
                                                 data.setApartment(e.target.value)
                                                 if(!houseNoRegex.test(e.target.value))
                                                 {setMsg(errorApartment)
                                                 }
                                                else{setMsg('')
                                                 }
                                             }
                                             
                                         }
                                
                                        
                                        />
                                        <label for="floatingPassword">Apartment</label>
                                    </div>
                                    <div class="form-floating mb-3">
                                        <input type="text" class="form-control rounded-pill" id="floatingPassword"
                                        placeholder='city'
                                        value={data.city}

                                         onChange={
                                             (e)=>{
                                                 data.setCity(e.target.value)
                                                 if(!nameRegex.test(e.target.value))
                                                 {setMsg(errorCity)
                                                 }
                                                else{setMsg('')
                                                 }
                                             }
                                             
                                         }
                                
                                        />
                                        <label for="floatingPassword">City</label>
                                    </div>
                                   
                                   


                                </div>
                            </div>
                        </div>



                    </form>

                </Modal.Body>
                <Modal.Footer>

                    <button className='btn btn-outline-secondary' onClick={handleClose}>Close</button>
                    <button className='btn btn-outline-primary' onClick={handleSubmit}>Submit</button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default AddEmployee;