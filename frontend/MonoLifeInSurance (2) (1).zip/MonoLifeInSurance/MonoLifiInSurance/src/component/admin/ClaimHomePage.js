import React from 'react'
import Navbar from '../shared/navbar/Navbar'
import Footer from '../shared/footer/Footer'
import { Navigate, useNavigate } from 'react-router-dom'

function ClaimHomePage() {
const navigate = new useNavigate()

  return (
    <div>
      <Navbar></Navbar>
            <div className='bg-warning text-center display-3 py-3 text-dark fw-bold'>Claims</div>
            <div className='container'>
                
                <div className='row my-5 justify-content-center'>
                    <div className='col-4'>
                        <div class="card d-flex bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text-center p-5 fw-bold fs-1'>Agent Claims</div>
                                    <button className='btn btn-lg btn-outline-success'
                                     
                                     onClick={()=>{navigate('/admin/agent_claim')}}

                                    >View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold p-5 fs-1'>Policy Claims</div>
                                    <button className='btn btn-lg btn-outline-success'
                                     onClick={()=>{navigate('/admin/policy_claim')}}
                                    >View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer></Footer>

        </div>
  )
}

export default ClaimHomePage