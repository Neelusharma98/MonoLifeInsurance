import React, { useEffect, useState } from "react";
import Table from "../shared/table/Table";
import PaginationApp from "../shared/page/PaginationApp";
import EditAgentDetails from "./EditAgentDetails";
import {
  GetAllAgent,
  DeleteAgentService,
  EditAgentService,
  SaveAgent,
} from "../../services/agent/Agent";
import PageSizeSetter from "../shared/page/PageSizeSetter";
import Navbar from "../shared/navbar/Navbar";
import { Alert } from "react-bootstrap";
import { Navigate, useNavigate } from "react-router-dom";
import { validateUser as validator } from "../../services/authservices/AuthServices";
import {
  eightCharAlphanumericPasswordRegex,
  emailRegex,
  houseNoRegex,
  mobileRegex,
  nameRegex,
  pinRegex,
} from "../../validation/Validation";
import {
  errorApartment,
  errorCity,
  errorEmail,
  errorFirstname,
  errorHouseNo,
  errorLastname,
  errorMobile,
  errorPassword,
  errorPin,
  errorState,
} from "../../validation/ErrorMessage";
import Agent from "../agent/Agent";
import { successAlet, warningAlert } from "../alerts/Alert";

const AddAgent = () => {
  const [pageSize, setPageSize] = useState(3);
  const [pageNumber, setPageNumber] = useState(0);
  const [data, setData] = useState([]);
  const [totalrecord, setTotalrecord] = useState();
  const [totalpage, setTotalpage] = useState();
  const [firstName, setFirstName] = useState();
  const [lastName, setLastName] = useState();
  const [mobile, setMobile] = useState();
  const [email, setEmail] = useState();
  const [dateOfBirth, setDateOfBirth] = useState();
  const [username, setUsername] = useState();
  const [password, setPassword] = useState();
  const [houseNo, setHouseNo] = useState();
  const [apartment, setApartment] = useState();
  const [city, setCity] = useState();
  const [pinCode, setPinCode] = useState();
  const [state, setState] = useState();
  const [employee, setEmployee] = useState();
  const [onDelete, setOnDelete] = useState();
  const [show, setShow] = useState(false);
  const [isValidUser, setIsValidUser] = useState(false);
  const [msg, setMsg] = useState();
  const [id, setId] = useState();

  const naviagte = new useNavigate();
  const getAgents = async () => {
    console.log("pageSize.............." + pageSize);
    console.log("pageNumb.............." + pageNumber);

    try {
      let response = await GetAllAgent(pageNumber, pageSize);
      console.log("request is", response.request.responseURL);
      console.log(response);
      if (response.data) {
        console.log("response==" + response.data.content);
        setData(response.data.content);
        setTotalrecord(response.headers["agent-count"]);
        console.log("total records +" + response.headers["agent-count"]);
        setTotalpage(Math.ceil(response.headers["agent-count"] / pageSize));
        console.log("page ct is " + totalpage);
      }
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  //   const ValidateUser = async () => {

  //     let authToken = localStorage.getItem("access_token");
  //     if (!authToken) {
  //       setIsValidUser(false);
  //       alert("login as a admin first!");
  //       naviagte("/");
  //     }
  //     console.log("auth value is " + authToken);
  //     let response = await validator(authToken);
  //     console.log("responce value is ", response.data.role);
  //     if (response.data.role != "ROLE_ADMIN") {
  //       setIsValidUser(false);
  //       naviagte("/");
  //       alert("login as a admin first!");
  //     }
  //     setIsValidUser(true);
  //   };

  //   useEffect(() => {
  //     ValidateUser();
  //   }, []);

  useEffect(() => {
    console.log("use effect 1 called");
    getAgents();
  }, [pageNumber, totalpage, totalrecord, employee, onDelete]);

  useEffect(() => {
    console.log("use effect 2 called");
    setPageNumber(0);
    getAgents();
  }, [pageSize]);

  const handleSubmit = async (e) => {
    try {
      console.log("inside handle-----------------------------------");
      e.preventDefault();

      let d = await SaveAgent(
        firstName,
        lastName,
        dateOfBirth,
        mobile,
        email,
        username,
        password,
        houseNo,
        apartment,
        city,
        pinCode,
        state
      );
      setEmployee(d);
      alert("Agent added successfully!");
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  const updateAgent = async (agent) => {
    setFirstName(agent.firstName);
    setLastName(agent.lastName);
    setEmail(agent.email);
    setMobile(agent.mobileNumber);
    setId(agent.id);
    setDateOfBirth(agent.dateOfBirth);
    setShow(true);

    console.log(
      "values are>>>>>>>>>>>>>>>>>>",
      agent.firstName,
      agent.lastName,
      agent.email,
      agent.mobileNumber,
      agent.id
    );
  };

  let d = {
    id,
    firstName,
    lastName,
    mobile,
    email,
    dateOfBirth,
  };

  const EditAgent = async () => {
    try {
      let response = await EditAgentService(d);
      successAlet("Agent updated successfully!");
      setEmployee(response);
    } catch (error) {
      warningAlert(error.response.data.message);
    }
  };

  const DeleteAgent = async (data) => {
    try {
      console.log("inside delete function", data.id);
      let response = await DeleteAgentService(data.id);
      setOnDelete(response);
      console.log(response);
    } catch (error) {
      alert(error.response.data.message);
    }
  };

  return (
    <div>
      <Navbar> </Navbar>
      {show && (
        <EditAgentDetails
          firstName={firstName}
          lastName={lastName}
          mobile={mobile}
          email={email}
          dob={dateOfBirth}
          show={show}
          setFirstName={setFirstName}
          setLastName={setLastName}
          setMobile={setMobile}
          setEmail={setEmail}
          setShow={setShow}
          setDateOfBirth={setDateOfBirth}
          editAgentData={EditAgent}
        ></EditAgentDetails>
      )}
      <div className="container">
        <div className="row">
          <div className="col-8 offset-2">
            <div className="text-center text-dark m-5 fw-bold">
              <h1>Add New Agent</h1>
            </div>
            <form className="shadow-lg p-5 rounded-border border-warning text-dark">
              <div className="text-danger text-center fw-bold">{msg}</div>
              <div className="h3 mb-4">Profile Details</div>
              <div className="row">
                <div className="col-6 mb-2">
                  <label for="exampleInputEmail1" className="form-label">
                    First Name*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    onChange={(e) => {
                      setFirstName(e.target.value);
                      if (!nameRegex.test(e.target.value)) {
                        setMsg(errorFirstname);
                      } else {
                        setMsg("");
                      }
                    }}
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div class="col-6 mb-2">
                  <label for="exampleInputPassword1" class="form-label">
                    Last Name*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setLastName(e.target.value);
                      if (!nameRegex.test(e.target.value)) {
                        setMsg(errorLastname);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <div className="row">
                <div className="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    Mobile
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setMobile(e.target.value);
                      if (!mobileRegex.test(e.target.value)) {
                        setMsg(errorMobile);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
                <div className="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    Email*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (!emailRegex.test(e.target.value)) {
                        setMsg(errorEmail);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <div className="row">
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    Username*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setUsername(e.target.value);
                    }}
                  />
                </div>
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    Password*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setPassword(e.target.value);
                      if (
                        !eightCharAlphanumericPasswordRegex.test(e.target.value)
                      ) {
                        setMsg(errorPassword);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <div className="row">
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    DateOfBirth*
                  </label>
                  <input
                     type="date" id="DOB" name="DOB" min="1979-01" max="2020-01"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      const selectedDate = e.target.value;
                      const formattedDate = new Date(selectedDate).toISOString().split('T')[0];
                      console.log(formattedDate);
                      setDateOfBirth(formattedDate);
                    }}
                  />
                </div>
              </div>
              <div className="h3 mb-4">Address</div>
              <div className="row">
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    HouseNo
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setHouseNo(e.target.value);
                      if (!houseNoRegex.test(e.target.value)) {
                        setMsg(errorHouseNo);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>

                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    Apartment*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setApartment(e.target.value);
                      if (!apartment.test(e.target.value)) {
                        setMsg(errorApartment);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <div className="row">
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    City*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setCity(e.target.value);
                      if (!nameRegex.test(e.target.value)) {
                        setMsg(errorCity);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>

                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    PinCode*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setPinCode(e.target.value);
                      if (!pinRegex.test(e.target.value)) {
                        setMsg(errorPin);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <div className="row">
                <div class="mb-2 col-6">
                  <label for="exampleInputPassword1" class="form-label">
                    State*
                  </label>
                  <input
                    type="text"
                    class="form-control rounded-pill text-dark fw-bold"
                    id="exampleInputPassword1"
                    onChange={(e) => {
                      setState(e.target.value);
                      if (!nameRegex.test(e.target.value)) {
                        setMsg(errorState);
                      } else {
                        setMsg("");
                      }
                    }}
                  />
                </div>
              </div>
              <button
                type="submit"
                class="btn btn-primary btn btn-lg rounded-pill border border-warning"
                onClick={handleSubmit}
              >
                Submit
              </button>
            </form>
          </div>
        </div>

        <div className="row mt-5 ">
          <div className="col-8 offset-1">
            <PaginationApp
              totalpage={totalpage}
              setpage={setPageNumber}
              pageNumber={pageNumber}
            ></PaginationApp>
          </div>

          <div className="col-2">
            <PageSizeSetter
              setPageSize={setPageSize}
              setTotalpage={setTotalpage}
              totalrecord={totalrecord}
              pageSize={pageSize}
              setPageNumber={setPageNumber}
            ></PageSizeSetter>
          </div>
        </div>

        <div className="col-10 offset-1">
          <div className="text-center">
            <label for="exampleInputPassword1" class="form-label">
              <h1>AgentDetails</h1>
            </label>
          </div>
          <div className="m-3 mb-5">
            <Table
              data={data}
              isDeleteButton={true}
              isUpdateButton={true}
              deleteFun={DeleteAgent}
              UpdateFun={updateAgent}
            ></Table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddAgent;
