import React from 'react'
import Navbar from '../shared/navbar/Navbar'
import employees from "../../images/employees.png"
import Footer from '../shared/footer/Footer'
import { useNavigate } from 'react-router-dom'



const Employee = () => {
    const navigate=new useNavigate();
    return (
        <div>
            <Navbar></Navbar>
            <div className='bg-warning text-center display-3 py-3 text-dark fw-bold'>Employee Dashboard</div>
            <div className='container'>

                <div className='row my-5'>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Profile</div>
                                    <button className='btn btn-lg btn-outline-success' onClick={()=>navigate('/edit_employee_detail')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Agent</div>
                                    <button className='btn btn-lg btn-outline-success' onClick={()=>navigate('/add_agent')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Query</div>
                                    <button className='btn btn-lg btn-outline-success'>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div className='row my-5 justify-content-center'>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Customer</div>
                                    <button className='btn btn-lg btn-outline-success'onClick={()=>navigate('/get_customers')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Policy</div>
                                    <button className='btn btn-lg btn-outline-success'onClick={()=>navigate('/aproov_policy')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Schemes</div>
                                    <button className='btn btn-lg btn-outline-success' onClick={()=>navigate('/show_scheme')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                <div className='row my-5 justify-content-center'>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Accounts</div>
                                    <button className='btn btn-lg btn-outline-success'onClick={()=>navigate('/get_all_accounts')}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>

            <Footer></Footer>

        </div>
    )
}

export default Employee