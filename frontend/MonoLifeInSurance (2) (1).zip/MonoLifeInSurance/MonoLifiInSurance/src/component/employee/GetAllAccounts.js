import React from 'react'
import GetPolicies from '../admin/GetPolicies'

function GetAllAccounts() {
  return (
    <div>
    <GetPolicies></GetPolicies>
    </div>
  )
}

export default GetAllAccounts