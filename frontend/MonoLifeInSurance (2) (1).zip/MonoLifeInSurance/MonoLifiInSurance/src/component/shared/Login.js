import React, { useState } from "react";

import Navbar from "./navbar/Navbar";
import Footer from "./footer/Footer";
import { useNavigate } from "react-router-dom";
import { loginService } from "../../services/authservices/AuthServices";
import logImage from "../../images/logImage.png"


const Login = () => {
  const [username, setUserName] = useState();
  const [password, setPassword] = useState();
  const [roleType, setRoleType] = useState();
  const navigate=new useNavigate();
  const handleLogin=async(e)=>{
    e.preventDefault();
    const response=await loginService(username,password,roleType);
    localStorage.setItem('auth',"Bearer "+response.data.accessToken)
    localStorage.setItem('username',response.data.username) 
    localStorage.setItem('Role',response.data.roleType) 
    if(response.data.roleType=="ROLE_ADMIN"){
        navigate('/admin')
    }
    else if( response.data.roleType=="ROLE_CUSTOMER" ){
        navigate('/customer')
    }
    else if( response.data.roleType=="ROLE_AGENT" ){
        navigate('/agent')
    }
    else if( response.data.roleType=="ROLE_EMPLOYEE" ){
        navigate('/employee')
    }
    else{
        navigate('/')
    }
  }
  return (
    <div>
      <Navbar></Navbar>
      <div className="container">
        <div className="row m-5 ">
          <div className="col-6  mt-5">
            <img className="" src={logImage} alt="login image" height={280} ></img>
            </div>
          <div className="col-6">
            <div
              className="border-1"
              
            >
              <div className="text-dark fs-1 text-center fw-bold mb-3 background2">
                Login
              </div>
              <form>
                <select
                  class="form-select py-3 mb-3 rounded-pill"
                  aria-label="Default select example"
                  onChange={(e)=>{
                    setRoleType(e.target.value)
                  }}
                >
                  <option selected>Login As</option>
                  <option value="ROLE_ADMIN">Admin</option>
                  <option value="ROLE_CUSTOMER">Customer</option>
                  <option value="ROLE_EMPLOYEE">Employee</option>
                  <option value="ROLE_AGENT">Agent</option>
                </select>
                <div class="form-floating mb-3">
                  <input
                    type="text"
                    class="form-control rounded-pill"
                    id="floatingInput"
                    onChange={(e)=>{
                        setUserName(e.target.value)
                    }}
                  />
                  <label for="floatingInput">Username</label>
                </div>
                <div class="form-floating">
                  <input
                    type="password"
                    class="form-control rounded-pill"
                    id="floatingPassword"
                    placeholder="Password"
                    onChange={(e)=>{
                        setPassword(e.target.value)
                    }}
                  />
                  <label for="floatingPassword">Password</label>
                </div>
                <div>
                  <button className="btn btn-lg px-3 fw-bold btn-primary my-3 ms-2"
                    onClick={handleLogin}
                  >
                    Login
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <Footer></Footer>
    </div>
  );
};

export default Login;
