import React from 'react'


    

function Tab({data,isUpdateButton,isDeleteButton,showMoreButton,isPayment,isDoc,isNominee,isClaim,isPay,isAproov,isReject,nomineeFun,claimFun,paymentFun,docFun,deleteFun,UpdateFun,detailFun,payFun,aproovFun,rejectFun}) {
    let headerdata=<></>;

    console.log("data in table is 888 ",data);
    
    if (data!=0) {
        console.log("data==",data);
        console.log("key=="+ Object.keys(data[0]))
        
        let key = Object.keys(data[0])
        if(isUpdateButton==true)
        {
        key.push('Update')
        }

        if(isDeleteButton==true)
        {
        key.push('Delete')
        }
        if(isDoc==true)
        {
        key.push('Document')
        }
        if(isPayment==true)
        {
        key.push('Payment')
        }
        if(showMoreButton==true)
        {
        key.push('Delails')
        }
        if(isNominee==true)
        {
        key.push('Nominee')
        }
        if(isPay==true)
        {
        key.push('Pay')
        }
        if(isClaim==true)
        {
        key.push('Claim')
        }
        if(isAproov==true)
        {
        key.push('Approve')
        }
        if(isReject==true)
        {
        key.push('Reject')
        }
       
        headerdata=key.map((d) => {
          return <th>{String(d).toUpperCase()}</th>;
        });
       
    }

    let rowofusers = <></>
    if (data.length > 0) {
        rowofusers = data.map((value,ind) => {
            return (
                <tr key={ind}>
                  
                    {
                        Object.values(value).map((t) => {
                            return (
                              
                                <td>{String(t).toUpperCase()}</td>
                            )
                        })
                    }
                    {isUpdateButton && <td><button type="button" className='btn btn-outline-primary' onClick={()=>{
                       console.log("data value in update >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      UpdateFun(value)
                    }}>update</button></td>}
                    {isDeleteButton && <td><button type="button" className='btn btn-outline-danger' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      deleteFun(value)
                    }}>Delete</button></td>}

                    {isDoc && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      docFun(value)
                    }}>Documents</button></td>}
                    {isPayment && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      paymentFun(value)
                    }}>Payments</button></td>}
                    {showMoreButton && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      detailFun(value)
                    }}>Details</button></td>}

                     {isNominee && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      nomineeFun(value)
                    }}>Nominee</button></td>}

                    {isPay && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      payFun(value)
                    }}>Pay</button></td>}

                     {isClaim && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      claimFun(value)
                    }}>claim</button></td>}
                    {isAproov && <td><button type="button" className='btn btn-outline-success' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      aproovFun(value)
                    }}>Approve</button></td>}
                    {isReject && <td><button type="button" className='btn btn-outline-danger' onClick={()=>{
                      console.log("data value is >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",value)
                      rejectFun(value)
                    }}>Reject</button></td>}

                    
                 
                </tr>
                
            )

        });
    }

return (<>
<table className="table  table-bordered shadow-lg table-info">
  <thead>
    <tr className='text-center'>
      {headerdata}
    </tr>
  </thead>
  <tbody className='text-center'>
    {rowofusers}
  </tbody>
</table>
</>)

}
export default Tab




