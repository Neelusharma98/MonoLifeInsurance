import React from 'react'
import employee from '../../images/Insurance.png'
import plan from '../../images/plan.jpg'
import Navbar from '../shared/navbar/Navbar'
import Footer from '../shared/footer/Footer'
import { useNavigate } from 'react-router-dom'

const Agent = () => {

    const navigate = new useNavigate();
    return (
        <div>
            <Navbar></Navbar>
            <div className='bg-warning text-center display-3 py-3 text-dark fw-bold'>Agent Dashboard</div>
            <div className='container'>
                <div className='row my-5'>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Profile</div>
                                    <button className='btn btn-lg btn-outline-success'
                                     onClick={
                                        ()=>{
                                            navigate('/agent_profile')
                                        }}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Marketting</div>
                                    <button className='btn btn-lg btn-outline-success'>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Customers</div>
                                    <button className='btn btn-lg btn-outline-success'
                                     onClick={
                                        ()=>{
                                            navigate('/add_customer')
                                        }}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <div className='row my-5 justify-content-center'>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Insurance Accounts</div>
                                    <button className='btn btn-lg btn-outline-success' onClick={
                                        ()=>{
                                            navigate('/agent_accounts')
                                        }}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Policy Payment</div>
                                    <button className='btn btn-lg btn-outline-success'>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-4'>
                        <div class="card d-flex p-5 bg1">
                            <div class="card-body d-flex align-items-center">
                                <div className='d-block '>
                                    <div className='text fw-bold fs-1'>Agent Commission</div>
                                    <button className='btn btn-lg btn-outline-success'
                                    onClick={
                                        ()=>{
                                            navigate('/agent/agent_commission')
                                        }}>View More</button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <Footer></Footer>

        </div>
    )
}

export default Agent