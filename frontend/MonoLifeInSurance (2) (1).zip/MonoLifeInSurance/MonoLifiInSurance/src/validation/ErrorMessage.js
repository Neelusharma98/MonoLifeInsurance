export const errorFirstname="First Name must contain only alphabets"
export const errorLastname="last name must contain only alphabets"
export const errorMobile="Mobile must contain only 10 digits"
export const errorEmail="email should be in valid format"
export const errorBankName="Bank name must contain only alphabets"
export const errorPassword="password is not valid"
export const errorIfsc="ifsc is not valid"
export const errorBranchName="Branch Name must contain only alphabets"
export const errorAbbreviation="Abbreviation should be in 6 character"
export const errorPin="Pincode should be 6 digit number"
export const errorHouseNo="Invalide house number"
export const errorApartment="Invalide apartment name"
export const errorCity="Invalide city name"
export const errorState="State is not valide"
export const errorSalary="Invalide salary Amount!"
export const errorMinAmount="Minimum amount should be greater then 10000!"
export const errorMaxAmount="Maximum amount should be greater then minimum amount!"
export const errorMinAge="MinAge should be greater then 2 year!"
export const errorMaxAge="MaxAge should be greater then minimum age!"
export const errorMinTime="Minimum investment time should be greater then 1 year!"
export const errorMaxTime="Maximum investment time should be greater then mintime!"






