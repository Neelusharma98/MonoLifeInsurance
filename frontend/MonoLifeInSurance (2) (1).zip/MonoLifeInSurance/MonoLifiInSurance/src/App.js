import { Route, Routes } from 'react-router-dom';
import './App.css';

import About from './component/shared/About'
import Contact from './component/shared/Contact'
import Login from './component/shared/Login';
import Admin from './component/admin/Admin'
import Customer from './component/customer/Customer'
import Agent from './component/agent/Agent'
import Home from './component/home/Home';
import Plan from './component/plan/Plan';
import Employee from './component/employee/Employee';
import AddAgent from './component/employee/AddAgent';
import AddEmployee from './component/admin/AddEmployee';
import AllEmployee from './component/admin/AllEmployee';
import AllPlans from './component/admin/AllPlans';
import Claims from './component/admin/Claims';
import EditEmployee from './component/admin/EditEmployee'
import EditPlan from './component/admin/EditPlan';
import Schemes from './component/admin/Schemes'
import EditEmployeeDetail from './component/employee/EditEmployeeDetail';
import AddCustomer from './component/agent/AddCustomer';
import AgentProfile from './component/agent/AgentProfile';
import CustomerProfile from './component/customer/CustomerProfile';
import BuyPlans from './component/plans/BuyPlans'
import ShowAccounts from './component/customer/ShowAccounts';
import AproovPolicy from './component/employee/AproovPolicy';
import Policy from './component/policy/Policy'
import ClaimHomePage from './component/admin/ClaimHomePage';
import AgentClaims from './component/admin/AgentClaims';
import AgentCommission from './component/agent/AgentCommission';
import PolicyClaims from './component/admin/PolicyClaims'
import UpdateScheme from './component/scheme/UpdateScheme'
import GetPolicies from './component/admin/GetPolicies';
import ShowScheme from './component/employee/ShowScheme';
import GetCustomers from './component/employee/GetCustomers';
import GetAllAccounts from './component/employee/GetAllAccounts';
import AgentAccounts from './component/agent/AgentAccounts';



function App() {
  return (
    <div>
      <Routes>
        
        <Route exact path='/' element={<Home></Home>}></Route>
        <Route exact path='/login' element={<Login></Login>}></Route>
        <Route exact path='/admin' element={<Admin></Admin>}></Route>
        <Route exact path='/customer' element={<Customer></Customer>}></Route>
        <Route exact path='/agent' element={<Agent></Agent>}></Route>
        <Route exact path='/contact' element={<Contact></Contact>}></Route>
        <Route exact path='/about' element={<About></About>}></Route>
        <Route exact path='/plans' element={<Plan></Plan>}></Route>
        <Route exact path='/employee' element={<Employee></Employee>}></Route>
        <Route exact path='/add_Agent' element={<AddAgent></AddAgent>}></Route>
        <Route exact path='/add_employee' element={<AddEmployee></AddEmployee>}></Route>
        <Route exact path='/all_employee' element={<AllEmployee></AllEmployee>}></Route>
        <Route exact path='/all_plan' element={<AllPlans></AllPlans>}></Route>
        <Route exact path='/claim' element={<Claims></Claims>}></Route>
        <Route exact path='/edit_employee' element={<EditEmployee></EditEmployee>}></Route>
        <Route exact path='/edit_plan' element={<EditPlan></EditPlan>}></Route>
        <Route exact path='/schemes' element={<Schemes></Schemes>}></Route>
        <Route exact path='/edit_employee_detail' element={<EditEmployeeDetail></EditEmployeeDetail>}></Route>
        <Route exact path='/add_customer' element={<AddCustomer></AddCustomer>}></Route>
        <Route exact path='/agent_profile' element={<AgentProfile></AgentProfile>}></Route>
        <Route exact path='/customer_profile' element={<CustomerProfile></CustomerProfile>}></Route>
        <Route exact path='/services' element={<BuyPlans></BuyPlans>}></Route>
        <Route exact path='/policy' element={<ShowAccounts></ShowAccounts>}></Route>
        <Route exact path='/aproov_policy' element={<AproovPolicy></AproovPolicy>}></Route>
        <Route exact path='/payments' element={<Policy></Policy>}></Route>
        <Route exact path='/admin/claim_home' element={<ClaimHomePage></ClaimHomePage>}></Route>
        <Route exact path='/admin/agent_claim' element={<AgentClaims></AgentClaims>}></Route>
        <Route exact path='/admin/policy_claim' element={<PolicyClaims></PolicyClaims>}></Route>
        <Route exact path='/agent/agent_commission' element={<AgentCommission></AgentCommission>}></Route>
        <Route exact path='/get_all_policy' element={<GetPolicies></GetPolicies>}></Route>
        <Route exact path='/show_scheme' element={<ShowScheme></ShowScheme>}></Route>
        <Route exact path='/get_customers' element={<GetCustomers></GetCustomers>}></Route>
        <Route exact path='/get_all_accounts' element={<GetAllAccounts></GetAllAccounts>}></Route>
        <Route exact path='/agent_accounts' element={<AgentAccounts></AgentAccounts>}></Route>
      </Routes>
      {/* <Home></Home> */}
    </div>
  );
}

export default App;
