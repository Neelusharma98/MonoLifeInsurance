import axios from "axios"

export const EditAgentService = async (  
    data
    
    )=> {
    try {
    let response = await axios.put(`http://localhost:8080/insuranceapp/agent`,data,{
       
        headers:
        {
            Authorization:localStorage.getItem('auth')
        },
    }
    )
    
    return response
    
    } catch (error) {
        throw error
    }
    }  


 export const AgentByUsername = async (username)=> {
        try {
            
        let response = await axios.get(`http://localhost:8080/insuranceapp/agent`,{
            params:
            {
                username:username,
                
                
            },
            headers:
            {
                Authorization:localStorage.getItem('auth')
            },
        }
        )
        
        return response
        
        } catch (error) {
            throw error
        }
        }  


        export const GetAllAgent = async (pageNumber=0,pageSize=10)=> {
            try {
                
            let response = await axios.get(`http://localhost:8080/insuranceapp/allAgents`,{
                params:
                {
                    pageNumber:pageNumber,
                    pageSize:pageSize
                    
                },
                headers:
                {
                    
                    Authorization:localStorage.getItem('auth')
                },
            }
            )
            
            return response
            
            } catch (error) {
                throw error
            }
            }  


    
    export const SaveAgent = async (       
        firstName,
        lastName,
       dateOfBirth,
       username,
       password,
        mobileNumber,
        email,
        houseNo,
        apartment,
        city,
       pincode,
        state)=> {
    
       try{
        console.log(localStorage.getItem("token value is -----------",localStorage.getItem('auth')))
        console.log(firstName,
            lastName,
           dateOfBirth,
           username,
           password,
            mobileNumber,
            email,
            houseNo,
            apartment,
            city,
           pincode,
            state)
        let response = await axios.post(`http://localhost:8080/insuranceapp/addagent`,{    
            firstName,
            lastName,
           dateOfBirth,
            mobileNumber,
            email,
            username,
            password,
            houseNo,
            apartment,
            city,
           pincode,
            state
        },
        {
        
        headers:
        {
            
            Authorization:localStorage.getItem('auth')
        }
        
       }
        )
        console.log("bank responce is ------"+response);
        return response
    } catch (error) {
        throw error
      }
        }
    
    
        
       export const DeleteAgentService = async(id)=>{
      
        try{
        console.log("inside delete customer")
        let response = await axios.delete(`http://localhost:8080/insuranceapp/agent`,{
           params:
           {
             id
           },
        headers:
        {
            Authorization:localStorage.getItem('auth')
        },
        })
    
    
        return response;
    } catch (error) {
        throw error
      }
    }
    
   
    export const getAgentDetail=async()=>{
        try {
            let response = await axios.get(
                'http://localhost:8080/insuranceapp/agentDetail',
                {
                    params: {
                       username:localStorage.getItem('username')
                    }
                    ,
                    headers: {
                        Authorization:localStorage.getItem('auth')
                    }
                }
    
            )
    
            return response;
    
        }
        catch (error) {
            throw error;
        }
    }


    export const agentClaim=async (data)=>{
        try {
    
            let response = await axios.post(
                'http://localhost:8080/insuranceapp/claim', data, {
                headers: {
                    Authorization:localStorage.getItem('auth')
                }
            }
    
            )
    
            return response;
        } catch (error) {
    
            throw error;
    
        }
    }



    export const getAgentPolicies = async (pageNumber,pageSize,username)=> {
        try {
             let agent = await AgentByUsername(username);
             let id =agent.data.id;
            
        let response = await axios.get(`http://localhost:8080/insuranceapp/allpolicies`,{
            params:
            {
                pageNumber,
                pageSize,
                id,
                
            },
            headers:
            {
                
                Authorization:localStorage.getItem('auth')
            },
        }
        )
        
        return response
        
        } catch (error) {
            throw error
        }
        }  