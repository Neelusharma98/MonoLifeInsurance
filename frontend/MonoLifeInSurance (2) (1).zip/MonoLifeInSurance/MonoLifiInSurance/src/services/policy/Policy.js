import axios from "axios";

export const addPolicy=async (data)=>{
    try {

        let response = await axios.post(
            'http://localhost:8080/insuranceapp/addpolicy', data, {
            headers: {
                Authorization:localStorage.getItem('auth')
            }
        }

        )

        return response;
    } catch (error) {

        throw error;

    }
}

export const getPolicy=async(pageNumber,username)=>{
    try {
        let response = await axios.get(
            'http://localhost:8080/insuranceapp/policy',
            {
                params: {
                    pageNumber,
                    username
                }
                ,
                headers: {
                    Authorization:localStorage.getItem('auth')
                }
            }

        )

        return response;

    }
    catch (error) {
        throw error;
    }

}

export const getAllAccounts=async(pageNumber,pageSize)=>{
    try {
        let response = await axios.get(
            'http://localhost:8080/insuranceapp/allpolicy',
            {
                params: {
                    pageNumber,
                    pageSize
                }
                ,
                headers: {
                    Authorization:localStorage.getItem('auth')
                }
            }

        )

        return response;

    }
    catch (error) {
        throw error;
    }

}




    export const addPayment=async (param)=>{
        try {
             console.log("params are-----------------",param)
            let response = await axios.post(
                'http://localhost:8080/insuranceapp/payment',param,
                  {
                headers: {
                    Authorization:localStorage.getItem('auth')
                  }
                }    
                
            )
    
            return response;
        } catch (error) {
    
            throw error;
    
        }
    }


    export const pandingPolicy=async (pageNumber)=>{
    
            let response = await axios.get(
                'http://localhost:8080/insuranceapp/PendingPolicy',{
                 params:
                  {
                    pageNumber
                  },
                headers: {
                    Authorization:localStorage.getItem('auth')
                  }
                } 
                
            )
    
            return response;
        
    }


    export const paylist=async (policyId)=>{
    
        let response = await axios.get(
            'http://localhost:8080/insuranceapp/payments',{
             params:
              {
                policyId
              },
            headers: {
                Authorization:localStorage.getItem('auth')
              }
            } 
            
        )

        return response;
    
}


export const approvePolicy=async (policyId)=>{
    try {
        console.log("id in service==",policyId)
        let response = await axios.get(
            'http://localhost:8080/insuranceapp/approvePolicy',{
             params:
              {
                policyId
              },
            headers: {
                Authorization:localStorage.getItem('auth')
              }
            } 
            
        )
    
        return response;
    } catch (error) {
        throw error;
    
    }
    

}


export const getClaim=async (param1)=>{
    try {
         console.log("params are-----------------",param1)
        let response = await axios.post(
            'http://localhost:8080/insuranceapp/claimPolicy',param1,
              {
            headers: {
                Authorization:localStorage.getItem('auth')
              }
            }    
            
        )

        return response;
    } catch (error) {

        throw error;

    }
}