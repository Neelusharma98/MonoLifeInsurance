import axios from "axios";



export const getAllCustomer = async (pageNumber=0,pageSize=10)=> {
try{
   
let response = await axios.get(`http://localhost:8080/insuranceapp/allCustomer`,{
    params:
    {
        pageNumber:pageNumber,
        pageSize:pageSize
        
    },
    headers:
    {
        Authorization:localStorage.getItem('auth')
    },
}
);

return response
} catch (error) {
    throw error
  }
}

export const saveCustomer = async (       
    data)=> {

   try{
    let response = await axios.post(`http://localhost:8080/insuranceapp/addcustomer`,data,
    {
    headers:
    {
        Authorization:localStorage.getItem('auth')
    }
    
   }
    )
    console.log("bank responce is ------"+response);
    return response
} catch (error) {
    throw error
  }
    }


   export const updateCustomerService = async(data)=>{

    try{
        console.log("data values are +----------------",data)
        let response = await axios.put(`http://localhost:8080/insuranceapp/customer`,data,{
        headers:
        {
            Authorization:localStorage.getItem('auth')
        }
        })


        return response;
        } catch (error) {
        throw error
      }
    }


    
   export const deleteCustomerService = async(customerId)=>{
  
    try{
    console.log("inside delete customer")
    let response = await axios.delete(`http://localhost:8080/insuranceapp/customer`,{
       params:
       {
         customerId
       },
    headers:
    {
        Authorization:localStorage.getItem('auth')
    },
    })


    return response;
} catch (error) {
    throw error
  }
}


export const getCustomerByUsername = async(username)=>
{
    try{
    let response = await axios.get(`http://localhost:8080/insuranceapp/customer`,{
       params:
       {
         username
       },
    headers:
    {
        Authorization:localStorage.getItem('auth')
    },
    })
    return response;
} catch (error) {
    throw error
  }
}

export const getAccounts = async(pageNumber,pageSize,username)=>
{
  let customer = await getCustomerByUsername(username)
  console.log("customer===========",customer)
  let id=customer.data.id;
    try{
    let response = await axios.get(`http://localhost:8080/insuranceapp/accounts`,{
       params:
       {
         pageNumber,
         pageSize,
         id
       },
    headers:
    {
        Authorization:localStorage.getItem('auth')
    },
    })
    return response;
} catch (error) {
    throw error
  }
}

