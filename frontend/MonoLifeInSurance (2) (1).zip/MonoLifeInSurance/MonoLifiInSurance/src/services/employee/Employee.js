import axios from "axios"

export const EditEmployeeService = async (  
    id,      
    firstName,
    lastName,
    mobile,
    email,
    dateOfBirth,
    )=> {
    try {
       console.log("inside edit ",id,      
       firstName,
       lastName,
       mobile,
       email,
       dateOfBirth,localStorage.getItem('auth')) 
    let response = await axios.put(`http://localhost:8080/insuranceapp/employee`,{
            id,     
            firstName,
            lastName,
            mobile,
            email,
            dateOfBirth
        
        },
        {
        headers:
        {
            Authorization:localStorage.getItem('auth')
        },
        }
    )
    
    return response
    
    } catch (error) {
        throw error
    }
    }  


 export const  EmployeeByUsername = async (username)=> {
        try {
            console.log("inside service 7777777777777777777777777777777")

        let response = await axios.get(`http://localhost:8080/insuranceapp/employee`,{
            params:
            {
                username:username,
                
                
            },
            headers:
            {
                Authorization:localStorage.getItem('auth')
            },
        }
        )
        return response
        
        } catch (error) {
            throw error
        }
        }  


        export const getAllEmployee = async (pageNumber=0,pageSize=10)=> {
            try {
                
            let response = await axios.get(`http://localhost:8080/insuranceapp/allemployee`,{
                params:
                {
                    pageNumber:pageNumber,
                    pageSize:pageSize
                    
                },
                headers:
                {
                    Authorization:localStorage.getItem('auth')
                },
            }
            )
            
            return response
            
            } catch (error) {
                throw error
            }
            }  


    
    export const saveEmployee = async (       
        firstName,
        lastName,
       dateOfBirth,
       username,
       password,
        mobile,
        email,
        houseNo,
        apartment,
        city,
       pinCode,
        state)=> {
    
       try{
        let response = await axios.post(`http://localhost:8080/insuranceapp/addcustomer`,{    
            firstName,
            lastName,
           dateOfBirth,
            mobile,
            email,
            username,
            password,
            houseNo,
            apartment,
            city,
           pinCode,
            state
        },
        {
        headers:
        {
            Authorization:localStorage.getItem('auth')
        }
        
       }
        )
        console.log("bank responce is ------"+response);
        return response
    } catch (error) {
        throw error
      }
        }
    
    
        
       export const deleteEmployee = async(customerId)=>{
      
        try{
        console.log("inside delete customer")
        let response = await axios.delete(`http://localhost:8080/insuranceapp/employee`,{
           params:
           {
             customerId
           },
        headers:
        {
            Authorization:localStorage.getItem('auth')
        },
        })
    
    
        return response;
    } catch (error) {
        throw error
      }
    }
    
   